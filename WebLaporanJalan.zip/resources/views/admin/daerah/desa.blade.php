@extends('layouts.admin')
@section('title')
    Desa
@endsection
@section('content')
  <div class="container">
        <div class="row mt-5">
            @if ($message = Session::get('success'))
            <div class="col-xl-12">
                <div class="alert alert-success alert-block mt-5">
                    <button type="button" class="close" data-dismiss="alert">×</button> 
                    <strong>{{ $message }}</strong>
                </div>
            </div>
            @endif
        </div>
        <div class="row">
            <a href="" class="btn btn-primary mb-2" data-target="#Tambah" data-toggle="modal">Tambah</a>
        </div>
        <div class="row">
          <div class="col-lg-6 ml-n3">
              <form action="{{ route('search.desa') }}" method="get">
                  <div class="input-group mb-3">
                      <input type="text" class="form-control" placeholder="Cari Desa" name="key" id="key" autocomplete="off">
                      <div type="text" class="input-group-append">
                          <button class="btn btn-primary px-4" type="submit" id="tombolCari">Cari</button>
                      </div>
                  </div>
              </form>
          </div>
      </div>
        <div id="table_data">
        <div class="row">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Desa</th>
                        <th scope="col">Kecamatan</th>
                        <th scope="col">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($desa as $d)
                    <tr>
                        <td>{{ $loop->iteration }}</td>
                        <td>{{ $d->nama }}</td>
                        @foreach($kcmtn as $k)
                        @if($k->id == $d->kecamatan_id)
                        <td>{{ $k->nama }}</td>
                        @endif
                        @endforeach
                        <td>
                            <a data-toggle="modal" data-target="#Edit{{ $d->id }}" role="button" class="btn btn-sm btn-success text-white">Ubah</a>
                            <a href="{{ route('hapus.desa',['id' => $d->id]) }}" role="button" class="btn btn-sm btn-danger">Hapus</a>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
            @if($data > 10)
            {!! $desa->links() !!}
            @endif
          </div>
        </div>
    </div>
<!-- Modal -->
<div class="modal fade" id="Tambah" tabindex="-1" role="dialog" aria-labelledby="TambahLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="TambahLabel">Tambah Data Desa</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="{{ route('admin.postdesa') }}" method="post">
            <div class="input-group mb-4">
                <input type="text" name="nama" id="nama" class="form-control" placeholder="Nama Desa">
            </div>
            <div class="input-group">
            <select class="custom-select" id="kecamatan_id" name="kecamatan_id" value="{{ old('kecamatan') }}">
              <option disabled selected>-- Kecamatan --</option>
                @foreach($kcmtn as $k)
                  <option value="{{ $k->id }}">{{ $k->nama }}</option>
                @endforeach
              </select>
            </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
        <button type="submit" class="btn btn-primary">Simpan</button>
        {{csrf_field()}}
        </form>
      </div>
    </div>
  </div>
</div>
@foreach($desa as $d)
<div class="modal fade" id="Edit{{ $d->id }}" tabindex="-1" role="dialog" aria-labelledby="TambahLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="TambahLabel">Ubah Data Desa</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="{{ route('update.desa',['id' => $d->id]) }}" method="post">
        {{ method_field('PUT') }}
            <div class="input-group mb-4">
                <input type="text" name="nama" id="nama" class="form-control" placeholder="Nama Desa" value="{{ $d->nama }}">
            </div>
            <select class="custom-select" id="kecamatan_id" name="kecamatan_id" value="{{ old('kecamatan') }}">
              <option disabled selected>-- Kecamatan --</option>
                @foreach($kcmtn as $k)
                  <option value="{{ $k->id }}" {{$k->id == $d->kecamatan_id  ? 'selected' : ''}}> {{ $k->nama }} </option>
                @endforeach
              </select>
            </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
        <button type="submit" class="btn btn-primary">Ubah</button>
        {{csrf_field()}}
        </form>
      </div>
    </div>
  </div>
</div>
@endforeach
@endsection