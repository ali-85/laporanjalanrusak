<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ditolak extends Model
{
    protected $fillable = ['laporan_id','alasan'];
}
