<?php $__env->startSection('title'); ?>
    Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <div class="container">
        <div class="row">
            <?php if($message = Session::get('success')): ?>
            <div class="col-xl-12">
                <div class="alert alert-success alert-block mt-5">
                    <button type="button" class="close" data-dismiss="alert">×</button> 
                    <strong><?php echo e($message); ?></strong>
                </div>
            </div>
            <?php endif; ?>
        </div>
        <div class="row d-flex justify-content-center mt-5">
            <!-- Card -->
            <div class="card">
                <!-- Card content -->
                <div class="card-body" style="width:13rem">
                <!-- Title -->
                <h4 class="card-title"><a>Count <i class="fas fa-users prefix-white"></i></a></h4>
                <!-- Text -->
                <p class="card-text"><h2 class="h2"><?php echo e($user); ?> Users</h2>
                    <small class="text-success"><?php echo e($user); ?> Verifikasi</small><br>
                    <small class="text-warning">0 Belum Verifikasi</small><br>
                    <small class="text-danger">0 Diblokir</small><br>
                </p>
                </div>
            </div>
            <div class="card">
                <!-- Card content -->
                <div class="card-body" style="width:13rem">
                <!-- Title -->
                <h4 class="card-title"><a>Count <i class="fas fa-list-alt prefix-white"></i></a></h4>
                <!-- Text -->
                <p class="card-text"><a href="<?php echo e(route('admin.semua')); ?>"><h2 class="h2"><?php echo e($laporan); ?> Laporan</h2></a>
                    <a href="<?php echo e(route('admin.laporan')); ?>"><small class="text-warning"><?php echo e($pending); ?> Masuk</small><br></a>
                    <a href="<?php echo e(route('admin.proses')); ?>"><small class="text-info"><?php echo e($proses); ?> Diproses</small><br></a>
                    <a href="<?php echo e(route('admin.selesai')); ?>"><small class="text-success"><?php echo e($selesai); ?> Selesai</small><br></a>
                    <a href="<?php echo e(route('admin.tolak')); ?>"><small class="text-danger"><?php echo e($tolak); ?> Ditolak</small><br></a>
                </p>
                </div>
            </div>
            <!-- Card -->
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WebLaporanJalan\resources\views/admin/index.blade.php ENDPATH**/ ?>