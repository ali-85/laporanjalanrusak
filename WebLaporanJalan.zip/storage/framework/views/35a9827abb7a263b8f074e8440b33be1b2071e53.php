<?php $__env->startSection('title'); ?>
    Semua User
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <div class="container">
        <div class="row mt-5">
            <?php if($message = Session::get('success')): ?>
            <div class="col-xl-12">
                <div class="alert alert-success alert-block mt-5">
                    <button type="button" class="close" data-dismiss="alert">×</button> 
                    <strong><?php echo e($message); ?></strong>
                </div>
            </div>
            <?php endif; ?>
        </div>
        <div class="row">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Nama</th>
                        <th scope="col">Email</th>
                        <th scope="col">Role</th>
                        <th scope="col">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($u->name); ?></td>
                        <td><?php echo e($u->email); ?></td>
                        <?php if($u->role == 1): ?>
                        <td>Admin</td>
                        <?php else: ?>
                        <td>User</td>
                        <?php endif; ?>
                        <td>
                            <?php if(!(Auth::user()->id == $u->id)): ?>
                            <a href="<?php echo e(route('user.delete',['id' => $u->id])); ?>" role="button" class="btn btn-danger">Hapus</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WebLaporanJalan\resources\views/admin/user.blade.php ENDPATH**/ ?>