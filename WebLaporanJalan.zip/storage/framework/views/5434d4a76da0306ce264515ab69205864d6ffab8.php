<?php $__env->startSection('title'); ?>
    Login Page
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">

    <!-- Outer Row -->
    <div class="row justify-content-center">

      <div class="col-lg-7">

        <div class="card o-hidden border-0 shadow-lg my-5">
          <div class="card-body p-0">
            <!-- Nested Row within Card Body -->
            <div class="row">
              <div class="col-lg">
                <div class="p-5">
                  <div class="text-center">
                    <h1 class="h4 text-gray-900 mb-4">Login Page !</h1>
                    <?php if(Session::has('success')): ?>
                <div class="row">
                  <div class="col-lg-12">
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                      <?php echo e(Session::get('success')); ?>

                      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                  </div>
                </div>
                    <?php endif; ?>
                    <?php if(Session::has('danger')): ?>
                <div class="row">
                  <div class="col-lg-12">
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                      <?php echo e(Session::get('danger')); ?>

                      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                  </div>
                </div>
                    <?php endif; ?>
                  </div>
                  <form class="user" method="post" action="<?php echo e(route('postLogin')); ?>">
                    <div class="form-group">
                      <input type="text" class="form-control" id="email" name="email" aria-describedby="emailHelp" placeholder="Masukkan Email...">
                    </div>
                    <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                    <div class="alert alert-danger alert-dismissible fade show"><?php echo e($message); ?>

                      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    <div class="form-group">
                      <input type="password" class="form-control" id="password" name="password" placeholder="Password">
                    </div>
                    <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                      <div class="alert alert-danger alert-dismissible fade show"><?php echo e($message); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    <button type="submit" class="btn btn-success btn-block">
                      Masuk
                    </button>
                    <?php echo e(csrf_field()); ?>

                  </form>
                  <hr>
                  <div class="text-center">
                    <a class="small text-success" href="<?php echo e(route('signup')); ?>">Buat Akun!</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>

    </div>

  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WebLaporanJalan\resources\views/auth/login.blade.php ENDPATH**/ ?>