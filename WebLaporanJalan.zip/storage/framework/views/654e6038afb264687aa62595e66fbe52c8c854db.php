<?php $__env->startSection('title'); ?>
    Laporan Saya
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
        <div class="row mt-5">
            <?php if($message = Session::get('success')): ?>
            <div class="col-xl-12">
                <div class="alert alert-success alert-block mt-5">
                    <button type="button" class="close" data-dismiss="alert">×</button> 
                    <strong><?php echo e($message); ?></strong>
                </div>
            </div>
            <?php endif; ?>
        </div>
        <div class="row">
            <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Alamat</th>
                        <th scope="col">Aksi</th>
                        <th scope="col">Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($d->alamat); ?></td>
                        <td>
                            <a href="<?php echo e(route('user.detail',['id'=> $d->id])); ?>" class="btn btn-primary text-white btn-sm">Detail</a>
                        </td>
                        <?php if($d->status == 'pending'): ?>
                        <td class="text-warning"><?php echo e($d->status); ?></td>
                        <?php elseif($d->status == 'diproses'): ?>
                        <td class="text-info"><?php echo e($d->status); ?></td>
                        <?php elseif($d->status == 'Selesai'): ?>
                        <td class="text-success"><?php echo e($d->status); ?></td>
                        <?php elseif($d->status == 'Ditolak'): ?>
                        <td class="text-danger"><a href="<?php echo e(route('laporan.detail',['id' => $d->id])); ?>" class="text-danger"><?php echo e($d->status); ?></a></td>
                        <?php endif; ?>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WebLaporanJalan\resources\views/home/laporan.blade.php ENDPATH**/ ?>