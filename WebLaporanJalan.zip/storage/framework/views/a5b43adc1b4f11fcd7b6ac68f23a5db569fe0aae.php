<?php $__env->startSection('title'); ?>
    Kecamatan
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <div class="container">
        <div class="row mt-5">
            <?php if($message = Session::get('success')): ?>
            <div class="col-xl-12">
                <div class="alert alert-success alert-block mt-5">
                    <button type="button" class="close" data-dismiss="alert">×</button> 
                    <strong><?php echo e($message); ?></strong>
                </div>
            </div>
            <?php endif; ?>
        </div>
        <div class="row">
            <a id="tambahBtn" href="" class="btn btn-primary mb-2" data-target="#Tambah" data-toggle="modal">Tambah</a>
        </div>
        <div class="row">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Kecamatan</th>
                        <th scope="col">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($d->nama); ?></td>
                        <td>
                            <a data-toggle="modal" data-target="#Edit<?php echo e($d->id); ?>" role="button" class="btn btn-sm btn-success text-white">Ubah</a>
                            <a onclick="return confirm('Semua Desa dalam kecamatan ini akan ikut terhapus. Tetap Hapus?')" href="<?php echo e(route('delete.kcmtn',['id' => $d->id])); ?>" role="button" class="btn btn-sm btn-danger">Hapus</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<!-- Modal -->
<div class="modal fade" id="Tambah" tabindex="-1" role="dialog" aria-labelledby="TambahLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="TambahLabel">Tambah Data Kecamatan</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="<?php echo e(route('admin.postcamat')); ?>" method="post">
            <div class="input-group">
                <input type="text" name="nama" id="nama" class="form-control" placeholder="Nama Kecamatan" autofocus>
            </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
        <button type="submit" class="btn btn-primary">Simpan</button>
        <?php echo e(csrf_field()); ?>

        </form>
      </div>
    </div>
  </div>
</div>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="Edit<?php echo e($d->id); ?>" tabindex="-1" role="dialog" aria-labelledby="TambahLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="TambahLabel">Ubah Data Kecamatan</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="<?php echo e(route('update.kcmtn',['id' => $d->id])); ?>" method="post">
        <?php echo e(method_field('PUT')); ?>

            <div class="input-group">
                <input type="text" name="nama" id="nama" class="form-control" placeholder="Nama Desa" value="<?php echo e($d->nama); ?>">
            </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
        <button type="submit" class="btn btn-primary">Ubah</button>
        <?php echo e(csrf_field()); ?>

        </form>
      </div>
    </div>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
  <script>
  $('#Tambah').on('shown.bs.modal', function() {
    $(this).find('#nama').focus();
  })
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WebLaporanJalan\resources\views/admin/daerah/kcmtn.blade.php ENDPATH**/ ?>