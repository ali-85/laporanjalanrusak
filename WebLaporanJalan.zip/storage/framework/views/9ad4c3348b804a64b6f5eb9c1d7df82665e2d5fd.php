<?php $__env->startSection('title'); ?>
    Alasan Ditolak
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
      <div class="row">
            <div class="card mt-5" style="width:32rem">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card-body">
                    <h5 class="card-title"> Alasan</h5>
                    <p class="card-text"><?php echo e($d->alasan); ?></p>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WebLaporanJalan\resources\views/home/alasan.blade.php ENDPATH**/ ?>