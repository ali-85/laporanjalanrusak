<?php $__env->startSection('title'); ?>
    Detail
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <div class="container">
      <div class="row">
            <div class="card mt-5" style="width:32rem">
                <?php $__currentLoopData = $laporan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lapor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <img onclick="fullscreen()" id="Image" src="<?php echo e(URL::to('/img/'.$lapor->image)); ?>" class="card-img-top" alt="image" height="256">
                <div class="card-body">
                    <h5 class="card-title">Pelapor : <?php echo e($lapor->nama); ?></h5>
                    <p class="card-text">No HP Pelapor : <?php echo e($lapor->nohp); ?></p>
                    <p class="card-text">Alamat : <?php echo e($lapor->alamat); ?></p>
                    <p class="card-text">Desa : <?php echo e($lapor->desa); ?></p>
                    <?php $__currentLoopData = $kcmtn; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($k->id == $lapor->kecamatan): ?>
                        <p class="card-text">Kecamatan : <?php echo e($k->nama); ?></p>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <p class="card-text">status : <?php echo e($lapor->status); ?></p>
                    <p class="card-text">Catatan : <?php echo e($lapor->note); ?></p>
                    <p class="card-text"><small class="text-muted">diunggah pada <?php echo e($lapor->created_at->format('H:i:s d/m/y')); ?></small></p>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
function fullscreen() {
    var divObj = document.getElementById("Image");
       //Use the specification method before using prefixed versions
      if (divObj.requestFullscreen) {
        divObj.requestFullscreen();
      }
      else if (divObj.msRequestFullscreen) {
        divObj.msRequestFullscreen();               
      }
      else if (divObj.mozRequestFullScreen) {
        divObj.mozRequestFullScreen();      
      }
      else if (divObj.webkitRequestFullscreen) {
        divObj.webkitRequestFullscreen();       
      } else {
        console.log("Fullscreen API is not supported");
      } 

    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WebLaporanJalan\resources\views/admin/detail.blade.php ENDPATH**/ ?>