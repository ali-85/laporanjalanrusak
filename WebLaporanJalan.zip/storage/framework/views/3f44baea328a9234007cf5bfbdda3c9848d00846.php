<?php $__env->startSection('title'); ?>
    Laporan Ditolak
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <div class="container">
        <div class="row mt-5">
            <?php if($message = Session::get('success')): ?>
            <div class="col-xl-12">
                <div class="alert alert-success alert-block mt-5">
                    <button type="button" class="close" data-dismiss="alert">×</button> 
                    <strong><?php echo e($message); ?></strong>
                </div>
            </div>
            <?php endif; ?>
        </div>
        <div class="row">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Tanggal</th>
                        <th scope="col">Pelapor</th>
                        <th scope="col">Lokasi</th>
                        <th scope="col">Gambar</th>
                        <th scope="col">Status</th>
                        <th scope="col">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $laporan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lapor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($lapor->created_at->format('d/m/y')); ?></td>
                        <td><?php echo e($lapor->nama); ?></td>
                        <td><?php echo e($lapor->alamat); ?></td>
                        <td>
                            <img src="<?php echo e(URL::to('/img/'.$lapor->image)); ?>" alt="jalan" width="128" height="64">
                        </td>
                        <td><?php echo e($lapor->status); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.detail',['id' => $lapor->id])); ?>" role="button" class="btn btn-sm btn-primary">detail</a>
                            <form action="<?php echo e(route('batal.tolak',['id' => $lapor->id])); ?>" method="post">
                            <button type="submit" role="button" class="btn btn-sm btn-success">Batalkan</button>
                            <?php echo e(csrf_field()); ?>

                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WebLaporanJalan\resources\views/admin/tolak.blade.php ENDPATH**/ ?>